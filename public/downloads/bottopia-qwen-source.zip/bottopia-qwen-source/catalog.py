"""Qwen-only source release; other recipes are not included."""
MODELS = {'qwen-custom': {'module': 'qwen_tts', 'packages': ['https://files.pythonhosted.org/packages/31/01/95f3ae26f5b7eb2105f69ad2c15af5a28b9ebdd1258a0b27541f5ebd6225/qwen_tts-0.1.1-py3-none-any.whl#sha256=11a290d8dabc7ef91a90c54478c8ab19b3edb1d85c0882313721892bdc4af15d'], 'python': '3.11'}, 'qwen-design': {'module': 'qwen_tts', 'packages': ['https://files.pythonhosted.org/packages/31/01/95f3ae26f5b7eb2105f69ad2c15af5a28b9ebdd1258a0b27541f5ebd6225/qwen_tts-0.1.1-py3-none-any.whl#sha256=11a290d8dabc7ef91a90c54478c8ab19b3edb1d85c0882313721892bdc4af15d'], 'python': '3.11'}}
LANGUAGES = {'qwen-custom': ['ko', 'en', 'ja', 'zh', 'de', 'fr', 'ru', 'pt', 'es', 'it'], 'qwen-design': ['ko', 'en', 'ja', 'zh', 'de', 'fr', 'ru', 'pt', 'es', 'it']}
VOICES = {'qwen-custom': ['Sohee', 'Vivian', 'Serena', 'Uncle_Fu', 'Dylan', 'Eric', 'Ryan', 'Aiden', 'Ono_Anna']}
REFERENCE_REQUIRED = set()
REFERENCE_ALLOWED = set()
